import dotenv  from "dotenv";
import connectToDataBase from "./database.js";
import express from "express";


dotenv.config()
connectToDataBase()

const app = express()

app.use(express.json())

const port = process.env.PORT ||  5000

app.listen(port, ()=> {
    console.log(`server is runnning on port: ${port}`);
})