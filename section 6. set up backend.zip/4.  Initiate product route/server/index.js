import dotenv  from "dotenv";
import connectToDataBase from "./database.js";
import express from "express";

// our routes
import productRoutes from "./routes/productRoutes.js";


dotenv.config()
connectToDataBase()

const app = express()

app.use(express.json())

const port = process.env.PORT ||  5000

app.use("/api/products", productRoutes)




app.listen(port, ()=> {
    console.log(`server is runnning on port: ${port}`);
})