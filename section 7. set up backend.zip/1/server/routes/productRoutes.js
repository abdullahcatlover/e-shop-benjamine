import  express  from "express";
import Product from "../modules/Product.js";
// !!!!!! import Product from "../modules/Product.js";  here if you skip js. it will give you error
const productRoutes = express.Router();


const getProducts = async (req, res) => {
    const products = await Product.find({});

    res.json(products)
}


productRoutes.route('/').get(getProducts)

export default productRoutes;