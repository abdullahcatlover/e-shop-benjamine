import { combineReducers, configureStore } from '@reduxjs/toolkit'

const reducer = combineReducers({
    
})


export default configureStore({
    reducer,
});