import {
    Box, Flex, Heading, HStack, Stack, Link, useColorModeValue,
    Spinner, Alert, AlertTitle, AlertIcon, AlertDescription, Wrap
} from '@chakra-ui/react'
import { Link as ReactLink } from "react-router-dom"


const CartScreen = () => {
    return (
        <Wrap spacing="30px" justify="center" minHeight="100vh">
            {loading ? (
                <Stack direction="row" spacing={4} >
                    <Spinner mt={50} thickness='10px' speed='1.85s'
                        emptyColor='gray.200' color='green.500' size="xl" w="250px" h={"250px"} />
                </Stack>
                // <p>Loading...</p>
            ) : error ? (
                <Alert status='error'>
                    <AlertIcon />
                    <AlertTitle>We are Sorry, something went wrong.</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            ) : cart.length <= 0 ? (
                <Alert status='warning'>
                <AlertIcon />
                <AlertTitle>Your Cart Is Empty</AlertTitle>
                <AlertDescription>
                    <Link as={ReactLink} to="/products">
                        Click here to see products
                    </Link>
                </AlertDescription>
             </Alert>
            ) : (<p>Display</p>
            )}
        </Wrap>
    
    )
}


export default CartScreen